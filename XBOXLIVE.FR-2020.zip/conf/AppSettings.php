<?php
  setlocale (LC_TIME, 'fr_FR.utf8','fra');
  $maindomain = $_SERVER['SERVER_NAME'];
  $http = 'http';
?>