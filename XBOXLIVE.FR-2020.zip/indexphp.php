<?php
	//session_start();
	//include('bibli.php');
	echo 'hello';
	//Errorreporting();
	//Controller();
	
	//Header();
?>
