<div><a href="/">Xboxlive.fr</a></div>
<div><a href="/register/">S'enregistrer</a></div>
