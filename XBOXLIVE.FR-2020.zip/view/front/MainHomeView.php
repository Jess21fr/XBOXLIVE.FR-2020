<?php ob_start(); ?>

HOME

<?php $content = ob_get_clean(); ?>

<?php require('template.php'); ?>
